// Invoke 'strict' JavaScript mode
'use strict';

// Define the module method
module.exports = function() {
	// Define functional variable
	var message = 'Hello';

	// Print the message variable to the console
	console.log(message);
};