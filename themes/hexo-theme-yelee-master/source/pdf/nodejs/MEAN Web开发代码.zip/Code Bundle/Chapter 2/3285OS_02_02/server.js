// Invoke 'strict' JavaScript mode
'use strict';

// Load the 'hello' module
var hello = require('./hello');

// Call the 'hello' module as a function
hello();