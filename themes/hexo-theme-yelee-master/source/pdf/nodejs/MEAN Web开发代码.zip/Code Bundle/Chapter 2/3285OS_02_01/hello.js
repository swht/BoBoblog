// Invoke 'strict' JavaScript mode
'use strict';

// Define a module variable
var message = 'Hello';

// Print message to the console
exports.sayHello = function() {
	console.log(message);
};