// Invoke 'strict' JavaScript mode
'use strict';

// Create the 'chat' module
angular.module('chat', []);