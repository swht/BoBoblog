module.exports = {
	db: 'mongodb://localhost/mean-book',
	sessionSecret: 'Your Application Session Secret',
	viewEngine: 'ejs'
};